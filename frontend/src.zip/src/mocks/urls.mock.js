export const urlsMock = {
}